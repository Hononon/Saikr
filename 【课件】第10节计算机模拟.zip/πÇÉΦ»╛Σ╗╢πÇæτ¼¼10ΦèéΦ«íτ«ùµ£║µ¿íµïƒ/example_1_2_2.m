clear
t=0;
j=0;
while t<3
   j=j+1
   t=t+exprnd(1/4)
end
   
