for k=1:n
for i=1 :n    
    for j=1:n        
        t=B(i,k)+B(k,j);
        if t<B(i,j)  B(i,j)=t; end 
        end        
    end
end  
