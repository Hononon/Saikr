function y=sir(t,x)
a=0.75;
b=0.25;
y=[a*x(1)*x(2)-b*x(1),-a*x(2),b*x(1)]';